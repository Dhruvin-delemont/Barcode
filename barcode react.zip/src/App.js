import React, { useState } from 'react';
import BarcodeReader from 'react-barcode-reader';
import logo from './logo.svg';
import './App.css';

function App() {
  const [barcode, setBarcode] = useState('');

  const handleScan = (data) => {
    setBarcode(data);
  };

  const handleError = (error) => {
    console.error(error);
  };

  return (
    <div>
      <h1>Barcode Scanner</h1>
      <BarcodeReader
        onScan={handleScan}
        onError={handleError}
      />
      <p>Scanned Barcode: {barcode}</p>
    </div>
  );
}

export default App;
